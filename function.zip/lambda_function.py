import boto3
import json
import logging

s3_client = boto3.client('s3')

# Bucket-urile țintă
SMALL_BUCKET = 'small-uploads'
MEDIUM_BUCKET = 'medium-uploads'
LARGE_BUCKET = 'large-uploads'

# Pragurile de dimensiune (în bytes)
SMALL_THRESHOLD = 1 * 1024 * 1024  # 1 MB
MEDIUM_THRESHOLD = 10 * 1024 * 1024  # 10 MB

# Configurare logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    try:
        logger.info(f"Event: {json.dumps(event)}")
        
        # Preia detaliile despre fișierul încărcat
        source_uploads_bucket = event['Records'][0]['s3']['bucket']['name']
        key = event['Records'][0]['s3']['object']['key']
        
        # Preia dimensiunea fișierului
        response = s3_client.head_object(Bucket=source_uploads_bucket, Key=key)
        file_size = response['ContentLength']
        
        # Determină bucket-ul țintă
        if file_size <= SMALL_THRESHOLD:
            target_bucket = SMALL_BUCKET
        elif file_size <= MEDIUM_THRESHOLD:
            target_bucket = MEDIUM_BUCKET
        else:
            target_bucket = LARGE_BUCKET
        
        # Mută fișierul în bucket-ul corespunzător
        copy_source = {'Bucket': source_uploads_bucket, 'Key': key}
        s3_client.copy_object(CopySource=copy_source, Bucket=target_bucket, Key=key)
        s3_client.delete_object(Bucket=source_uploads_bucket, Key=key)
        
        return {
            'statusCode': 200,
            'body': f'Successfully moved {key} to {target_bucket}'
        }
    
    except KeyError as e:
        logger.error(f"KeyError: {str(e)}")
        return {
            'statusCode': 400,
            'body': f'Error processing event: {str(e)}'
        }
    except Exception as e:
        logger.error(f"Exception: {str(e)}")
        return {
            'statusCode': 500,
            'body': f'Internal server error: {str(e)}'
        }
